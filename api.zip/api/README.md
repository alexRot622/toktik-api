
# Project IDP - TokTik

A fullstack project that simulates a platform for uploading videos to be seen by a large audience




## How to use Docker Swarm for containers' orchestration

Following commands have to be executed in different scenarios:

 - if you are using WSL, this is used to initialize a node where containers will be running
```bash
docker swarm init
```
- to deploy your stack of containers
```bash
docker stack deploy -c docker-compose.yml idp
```
"idp" value can be replaced with any other string

- to stop the orchestration
```bash
docker stack rm idp
```

- to find out what IP your node is using
```bash
docker node inspect self --format '{{ .Status.Addr  }}'
```




## Future release

In the next release Docker Swarm will be replaced by Kubernetes

