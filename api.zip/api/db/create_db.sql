CREATE TABLE IF NOT EXISTS Account (
    id         SERIAL       PRIMARY KEY,
    username   VARCHAR(50)  NOT NULL UNIQUE,
    email      VARCHAR(255) NOT NULL UNIQUE,
    last_video TIMESTAMP    NOT NULL DEFAULT NOW(),
    created_at TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Board (
    id          SERIAL       PRIMARY KEY,
    name        VARCHAR(50)  NOT NULL UNIQUE,
    description VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Video (
    id          SERIAL      PRIMARY KEY,
    blob_id     VARCHAR(64) NOT NULL,
    board_id    INTEGER     NOT NULL,
    uploaded_by INTEGER     NOT NULL,
    created_at  TIMESTAMP   NOT NULL DEFAULT NOW(),
    no_likes    INTEGER     NOT NULL DEFAULT 0,

    FOREIGN KEY (uploaded_by) REFERENCES Account(id),
    FOREIGN KEY (board_id) REFERENCES board(id)
);

CREATE TABLE IF NOT EXISTS Memberships (
  id        SERIAL    PRIMARY KEY,
  user_id   INTEGER   NOT NULL,
  board_id  INTEGER   NOT NULL,
  joined_at TIMESTAMP NOT NULL DEFAULT NOW(),

  FOREIGN KEY (user_id) REFERENCES Account(id) ON DELETE CASCADE,
  FOREIGN KEY (board_id) REFERENCES board(id) ON DELETE CASCADE
);

INSERT INTO board VALUES (1, 'random', 'Everything goes here');
INSERT INTO board VALUES (2, 'sports', 'Sports news and highlights');
INSERT INTO board VALUES (3, 'movies', 'Clips, news, release announcements');
INSERT INTO account VALUES (1, 'admin', 'admin@toktik.com');
INSERT INTO Memberships VALUES (1, 1, 1);

-- Synchronize ID sequences
SELECT setval(pg_get_serial_sequence('board', 'id')
            , COALESCE(max(id) + 1, 1)
            , false)
FROM board;

SELECT setval(pg_get_serial_sequence('account', 'id')
            , COALESCE(max(id) + 1, 1)
            , false)
FROM account;

SELECT setval(pg_get_serial_sequence('memberships', 'id')
            , COALESCE(max(id) + 1, 1)
            , false)
FROM memberships;

-- indexes
CREATE INDEX idx_blob_video
ON video (blob_id);
CREATE INDEX idx_video_time
ON video (created_at);